# parciales-viejos
Repositorio con parciales de Algoritmo 3, de cuatrimestres anteriores
